#!/bin/bash

NR_ASIGURARE="^[A-Z]{2}[0-9]{5}$"
FARMACIE="Med"
NUME_PRENUME="[A-Z][a-z]+\ [A-Z][a-z]+"
dd="\([0-2][0-9]\|(3)[0-1]\)"
MM="\(\(\(0\)[0-9]\)\|\(\(1\)[0-2]\)\)"
yyyy="\([0-2][0-9][0-9][0-9]\)"
DATA="${dd}\(\.\)${MM}\(\.\)${yyyy}"

# Verifică dacă numărul de argumente este egal cu 2
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 director_sursa director_destinatie"
    exit 1
fi

# Verifică dacă argumentele sunt directoare valide
if [ ! -d "$1" ] || [ ! -d "$2" ]; then
    echo "Error: The arguments must be valid directories."
    exit 1
fi

# Funcție pentru validarea unei linii din fișier
validate_line() {
    local line="$1"
    # Validează numărul de asigurare
    nr_asigurare=$(echo "$line" | cut -d ',' -f 1)
    nume_prenume=$(echo "$line" | cut -d ',' -f 2)
    farmacie=$(echo "$line" | cut -d ',' -f 3)
    data=$(echo "$line" | cut -d ',' -f 4)

    if !(echo "$nr_asigurare" | grep -qE "$NR_ASIGURARE"); then
        echo "$nr_asigurare"
    fi

    # Verificare validitate
    if  !(echo "$nume_prenume" | grep -q "$NUME_PRENUME") &&\
        !(echo "$farmacie" | grep -q "$FARMACIE") &&\
        !(echo "$data" | grep -q "$DATA"); then
      
        return 1
    fi
    # echo "$nr_asigurare $nume_prenume $farmacie $data"
    return 0
}

# Initializare variabile pentru statistica
total_files_processed=0
total_lines_processed=0

# Iterare prin fișierele din directorul sursă
for file in "$1"/*.txt; do
    filename=$(basename "$file")
    valid_clients=0

    # Citirea fiecărei linii din fișier
    while IFS= read -r line || [ -n "$line" ]; do
        if validate_line "$line"; then
            valid_clients=$((valid_clients + 1))
            echo "$line" >> "$2"/rezultat.txt
        fi
        total_lines_processed=$((total_lines_processed + 1))
    done < "$file"

    # Scrierea statisticilor pentru fiecare fișier
    echo "$filename: $valid_clients" >> "$2"/statistica.txt
    total_files_processed=$((total_files_processed + 1))
done

# Scrierea statisticilor finale
echo "Total files processed: $total_files_processed" >> "$2"/statistica.txt
echo "Total lines processed: $total_lines_processed" >> "$2"/statistica.txt

# Sortarea rezultatelor după dată
sort -t',' -k4,4 -n -o "$2"/rezultat.txt "$2"/rezultat.txt

sed -i 's/\([0-9]\{2\}\)\.\([0-9]\{2\}\)\.\([0-9]\{4\}\)/\1\/\2\/\3/g' "$2"/rezultat.txt