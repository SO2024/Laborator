#!/bin/bash

# Funcție recursivă pentru afișarea structurii arborescente
display_tree() {
    local directory="$1"
    local indent="$2"

    # Afișăm numele directorului cu indentare
    echo "${indent} └── $(basename "$directory")/"
    
    # Incrementăm indentarea pentru subdirectoare
    indent="$indent    "

    # Parcurgem fiecare element din director
    for item in "$directory"/*; do
        # Verificăm dacă elementul este un director
        if [ -d "$item" ]; then
            # Apelăm recursiv funcția pentru subdirector
            display_tree "$item" "$indent"
        elif [ -f "$item" ]; then
            # Afișăm numele fișierului și dimensiunea cu indentare
            ssize_in_bytes=$(stat -c "%s" "$item")
            echo "${indent}└── $(basename "$item") ($ssize_in_bytes bytes)"
        fi
    done
}

# Verificăm dacă există un argument pentru directorul de afișat
if [ $# -eq 0 ]; then
    # Dacă nu există, utilizăm directorul curent
    directory="."
else
    # Altfel, utilizăm directorul specificat ca argument
    directory="$1"
fi

# Afișăm structura arborescentă
display_tree "$directory" ""
