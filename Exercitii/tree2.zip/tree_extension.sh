#!/bin/bash

# Funcție recursivă pentru afișarea structurii arborescente
display_tree() {
    local directory="$1"
    local indent="$2"
    local extensie="$3"

    # Afișăm numele directorului cu indentare
    echo "${indent}└── $(basename "$directory")/"
    
    # Incrementăm indentarea pentru subdirectoare
    indent="$indent    "

    # Parcurgem fiecare element din director
    for item in "$directory"/*; do
        # Verificăm dacă elementul este un director
        if [ -d "$item" ]; then
            # Apelăm recursiv funcția pentru subdirector
            display_tree "$item" "$indent" "$extensie"
        elif [ -f "$item" ]; then
            # Afișăm numele fișierului și dimensiunea în biți cu indentare
            size_in_bytes=$(stat -c "%s" "$item")
            size_in_bits=$((size_in_bytes * 8))
            echo "${indent}└── $(basename "$item") ($size_in_bits bits)"

            # Verificăm dacă fișierul are extensia specificată
            if basename "$item" | grep -q "\.$extensie$"; then
                # Afișăm primele 5 linii din fișier
                echo "${indent}│   └── Primele 5 linii:"
                head -n 5 "$item" | sed "s/^/${indent}│   │   /"
            fi
        fi
    done
}

# Verificăm dacă există un argument pentru directorul de afișat și extensia fișierelor
if [ $# -lt 1 ]; then
    echo "Usage: $0 <directory> [extension]"
    exit 1
fi

directory="$1"
extensie="$2"

# Dacă nu există, utilizăm directorul curent
if [ -z "$directory" ]; then
    directory="."
fi

# Afișăm structura arborescentă
display_tree "$directory" "" "$extensie"
